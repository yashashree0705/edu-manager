const admin = require("firebase-admin");
const serviceAccount = require("./serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

// Replace with your Firebase Auth UID
const uid = "q6XmeuxxT0OWiHNh4OwZkOFBwKP2";

admin.auth().setCustomUserClaims(uid, { role: "admin" })
  .then(() => {
    console.log(`✅ Admin role assigned to user: ${uid}`);
    process.exit();
  })
  .catch((error) => {
    console.error("❌ Error assigning role:", error);
    process.exit(1);
  });
