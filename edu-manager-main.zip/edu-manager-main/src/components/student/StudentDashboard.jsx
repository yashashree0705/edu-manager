// src/components/student/StudentDashboard.jsx
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import firestoreService from '../../services/firestoreService';
import storageService from '../../services/storageService';
import { 
  Calendar, FileText, LogOut, Download, Upload, 
  Clock, BookOpen, CheckCircle, AlertCircle 
} from 'lucide-react';

const StudentDashboard = () => {
  const { userData, signOut } = useAuth();
  const [activeTab, setActiveTab] = useState('assignments');
  const [assignments, setAssignments] = useState([]);
  const [timetable, setTimetable] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);

  // Submission State
  const [submitting, setSubmitting] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedAssignment, setSelectedAssignment] = useState(null);
  const [submissionFile, setSubmissionFile] = useState(null);
  const [submissionNotes, setSubmissionNotes] = useState('');

  useEffect(() => {
    loadData();

    // Set up real-time listener for timetable
    const unsubscribe = firestoreService.onTimetableSnapshot(
      userData?.class,
      (data) => setTimetable(data)
    );

    return () => unsubscribe && unsubscribe();
  }, [userData]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [assignmentsData, timetableData, submissionsData] = await Promise.all([
        firestoreService.getAssignments(userData?.class),
        firestoreService.getTimetables(userData?.class),
        firestoreService.getSubmissions(null, userData?.uid)
      ]);
      
      setAssignments(assignmentsData);
      setTimetable(timetableData);
      setSubmissions(submissionsData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      try {
        storageService.validateFile(file, 10);
        setSubmissionFile(file);
      } catch (error) {
        alert(error.message);
        e.target.value = '';
      }
    }
  };

  const handleSubmitAssignment = async () => {
    if (!submissionFile) {
      alert('Please select a file to submit');
      return;
    }

    setSubmitting(true);
    setUploadProgress(0);

    try {
      // Upload file
      const uploadResult = await storageService.uploadSubmission(
        submissionFile,
        selectedAssignment.id,
        userData.uid,
        (progress) => setUploadProgress(progress)
      );

      // Create submission record
      await firestoreService.addSubmission({
        assignmentId: selectedAssignment.id,
        assignmentTitle: selectedAssignment.title,
        studentId: userData.uid,
        studentName: userData.name,
        class: userData.class,
        fileUrl: uploadResult.url,
        fileName: uploadResult.name,
        notes: submissionNotes,
        status: 'submitted'
      });

      // Log activity
      await firestoreService.addSystemLog({
        action: 'Assignment Submitted',
        user: userData.name,
        details: `Submitted ${selectedAssignment.title}`
      });

      alert('Assignment submitted successfully!');
      
      // Reset form
      setSelectedAssignment(null);
      setSubmissionFile(null);
      setSubmissionNotes('');
      setUploadProgress(0);
      
      loadData();
    } catch (error) {
      console.error('Error submitting assignment:', error);
      alert('Failed to submit assignment');
    } finally {
      setSubmitting(false);
    }
  };

  const isSubmitted = (assignmentId) => {
    return submissions.some(sub => sub.assignmentId === assignmentId);
  };

  const getSubmissionStatus = (assignmentId) => {
    const submission = submissions.find(sub => sub.assignmentId === assignmentId);
    if (!submission) return null;
    return submission;
  };

  const handleDownloadFile = async (fileUrl, fileName) => {
    try {
      window.open(fileUrl, '_blank');
    } catch (error) {
      console.error('Error downloading file:', error);
      alert('Failed to download file');
    }
  };

  const handleLogout = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const getDaysOrder = () => ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  
  const groupedTimetable = timetable.reduce((acc, entry) => {
    if (!acc[entry.day]) acc[entry.day] = [];
    acc[entry.day].push(entry);
    return acc;
  }, {});

  // Sort entries by period within each day
  Object.keys(groupedTimetable).forEach(day => {
    groupedTimetable[day].sort((a, b) => 
      parseInt(a.period) - parseInt(b.period)
    );
  });

  const pendingAssignments = assignments.filter(a => !isSubmitted(a.id));
  const submittedAssignments = assignments.filter(a => isSubmitted(a.id));

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Bar */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-purple-600">Student Dashboard</h1>
              <p className="text-sm text-gray-600">
                {userData?.name} • Class {userData?.class}
              </p>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition"
            >
              <LogOut size={16} />
              Logout
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pending Assignments</p>
                <p className="text-2xl font-bold text-orange-600">{pendingAssignments.length}</p>
              </div>
              <AlertCircle className="text-orange-600" size={32} />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Submitted</p>
                <p className="text-2xl font-bold text-green-600">{submittedAssignments.length}</p>
              </div>
              <CheckCircle className="text-green-600" size={32} />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Classes</p>
                <p className="text-2xl font-bold text-purple-600">{timetable.length}</p>
              </div>
              <BookOpen className="text-purple-600" size={32} />
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto">
          <button
            onClick={() => setActiveTab('assignments')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium whitespace-nowrap ${
              activeTab === 'assignments' 
                ? 'bg-purple-600 text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            <FileText size={20} />
            Assignments
          </button>
          <button
            onClick={() => setActiveTab('timetable')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium whitespace-nowrap ${
              activeTab === 'timetable' 
                ? 'bg-purple-600 text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            <Calendar size={20} />
            Timetable
          </button>
        </div>

        {/* Assignments Tab */}
        {activeTab === 'assignments' && (
          <div className="space-y-6">
            {/* Pending Assignments */}
            {pendingAssignments.length > 0 && (
              <div className="bg-white rounded-lg shadow">
                <div className="p-6 border-b">
                  <h2 className="text-xl font-bold text-orange-600">Pending Assignments</h2>
                  <p className="text-sm text-gray-600 mt-1">Complete these assignments before the due date</p>
                </div>
                <div className="p-6 space-y-4">
                  {pendingAssignments.map(assignment => (
                    <div key={assignment.id} className="p-4 border-2 border-orange-200 rounded-lg hover:shadow-md transition bg-orange-50">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-start gap-2">
                            <AlertCircle className="text-orange-600 flex-shrink-0 mt-1" size={20} />
                            <div>
                              <h3 className="font-semibold text-lg">{assignment.title}</h3>
                              <div className="flex flex-wrap gap-2 mt-2">
                                <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-sm">
                                  {assignment.subject}
                                </span>
                                <span className="px-2 py-1 bg-red-100 text-red-700 rounded text-sm flex items-center gap-1">
                                  <Clock size={14} />
                                  Due: {assignment.dueDate}
                                </span>
                              </div>
                              <p className="text-sm text-gray-700 mt-2">{assignment.description}</p>
                              {assignment.fileName && (
                                <p className="text-xs text-gray-600 mt-2">
                                  📎 Attachment: {assignment.fileName}
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col gap-2 ml-4">
                          {assignment.fileUrl && (
                            <button
                              onClick={() => handleDownloadFile(assignment.fileUrl, assignment.fileName)}
                              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 whitespace-nowrap"
                            >
                              <Download size={16} />
                              Download
                            </button>
                          )}
                          <button
                            onClick={() => setSelectedAssignment(assignment)}
                            className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 whitespace-nowrap"
                          >
                            <Upload size={16} />
                            Submit
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Submitted Assignments */}
            {submittedAssignments.length > 0 && (
              <div className="bg-white rounded-lg shadow">
                <div className="p-6 border-b">
                  <h2 className="text-xl font-bold text-green-600">Submitted Assignments</h2>
                  <p className="text-sm text-gray-600 mt-1">Your completed submissions</p>
                </div>
                <div className="p-6 space-y-4">
                  {submittedAssignments.map(assignment => {
                    const submission = getSubmissionStatus(assignment.id);
                    return (
                      <div key={assignment.id} className="p-4 border-2 border-green-200 rounded-lg bg-green-50">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-start gap-2">
                              <CheckCircle className="text-green-600 flex-shrink-0 mt-1" size={20} />
                              <div>
                                <h3 className="font-semibold text-lg">{assignment.title}</h3>
                                <div className="flex flex-wrap gap-2 mt-2">
                                  <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-sm">
                                    {assignment.subject}
                                  </span>
                                  <span className="px-2 py-1 bg-green-100 text-green-700 rounded text-sm">
                                    ✓ Submitted
                                  </span>
                                </div>
                                <p className="text-sm text-gray-700 mt-2">{assignment.description}</p>
                                {submission && (
                                  <div className="mt-2 text-xs text-gray-600">
                                    <p>Submitted: {submission.submittedAt?.toDate?.()?.toLocaleString()}</p>
                                    <p>File: {submission.fileName}</p>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* No Assignments */}
            {assignments.length === 0 && (
              <div className="bg-white rounded-lg shadow p-12 text-center">
                <FileText className="mx-auto text-gray-400 mb-4" size={48} />
                <p className="text-gray-500 text-lg">No assignments available yet</p>
                <p className="text-gray-400 text-sm mt-2">Check back later for new assignments</p>
              </div>
            )}
          </div>
        )}

        {/* Timetable Tab */}
        {activeTab === 'timetable' && (
          <div className="bg-white rounded-lg shadow">
            <div className="p-6 border-b">
              <h2 className="text-xl font-bold">My Timetable - Class {userData?.class}</h2>
              <p className="text-sm text-gray-600 mt-1">Your weekly class schedule</p>
            </div>

            <div className="p-6">
              {timetable.length === 0 ? (
                <div className="text-center py-12">
                  <Calendar className="mx-auto text-gray-400 mb-4" size={48} />
                  <p className="text-gray-500">No timetable available yet</p>
                </div>
              ) : (
                <div className="space-y-6">
                  {getDaysOrder().map(day => (
                    groupedTimetable[day] && (
                      <div key={day}>
                        <h3 className="font-bold text-lg text-purple-600 mb-3">{day}</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                          {groupedTimetable[day].map(entry => (
                            <div key={entry.id} className="p-4 border rounded-lg hover:shadow-md transition bg-purple-50">
                              <div className="flex items-start justify-between">
                                <div>
                                  <p className="text-sm text-gray-600">Period {entry.period}</p>
                                  <h4 className="font-semibold text-lg text-purple-700">{entry.subject}</h4>
                                  <p className="text-sm text-gray-700 mt-1">{entry.teacher}</p>
                                </div>
                                <div className="text-right">
                                  <p className="text-sm font-medium text-gray-600">{entry.time}</p>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Submission Modal */}
      {selectedAssignment && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b">
              <h2 className="text-xl font-bold">Submit Assignment</h2>
              <p className="text-sm text-gray-600 mt-1">{selectedAssignment.title}</p>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Upload Your Work *
                </label>
                <input
                  type="file"
                  onChange={handleFileSelect}
                  className="w-full px-4 py-2 border rounded-lg"
                  disabled={submitting}
                />
                {submissionFile && (
                  <p className="mt-2 text-sm text-gray-600">
                    Selected: {submissionFile.name} ({storageService.formatFileSize(submissionFile.size)})
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Notes (Optional)
                </label>
                <textarea
                  value={submissionNotes}
                  onChange={(e) => setSubmissionNotes(e.target.value)}
                  placeholder="Add any notes or comments..."
                  className="w-full px-4 py-2 border rounded-lg"
                  rows="3"
                  disabled={submitting}
                />
              </div>

              {submitting && (
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-purple-600 h-2 rounded-full transition-all"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
              )}
            </div>

            <div className="p-6 border-t flex gap-2">
              <button
                onClick={handleSubmitAssignment}
                disabled={submitting || !submissionFile}
                className="flex-1 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50"
              >
                {submitting ? `Submitting... ${Math.round(uploadProgress)}%` : 'Submit Assignment'}
              </button>
              <button
                onClick={() => {
                  setSelectedAssignment(null);
                  setSubmissionFile(null);
                  setSubmissionNotes('');
                  setUploadProgress(0);
                }}
                disabled={submitting}
                className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentDashboard;