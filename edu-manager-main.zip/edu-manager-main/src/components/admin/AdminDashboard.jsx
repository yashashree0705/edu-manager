// src/components/admin/AdminDashboard.jsx
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import firestoreService from '../../services/firestoreService';
import { 
  Users, Calendar, FileText, Bell, LogOut, Plus, Trash2, 
  Edit2, Search, Clock, BookOpen, AlertCircle, CheckCircle 
} from 'lucide-react';

const AdminDashboard = () => {
  const { userData, signOut } = useAuth();
  const [activeTab, setActiveTab] = useState('users');
  const [users, setUsers] = useState([]);
  const [timetables, setTimetables] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [systemLogs, setSystemLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  // User Management State
  const [showAddUser, setShowAddUser] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    role: 'student',
    class: ''
  });

  // Timetable Management State
  const [showAddTimetable, setShowAddTimetable] = useState(false);
  const [newTimetable, setNewTimetable] = useState({
    class: '',
    day: 'Monday',
    period: '1',
    subject: '',
    teacher: '',
    time: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [usersData, timetablesData, assignmentsData, logsData] = await Promise.all([
        firestoreService.getUsers(),
        firestoreService.getTimetables(),
        firestoreService.getAssignments(),
        firestoreService.getSystemLogs()
      ]);
      
      setUsers(usersData);
      setTimetables(timetablesData);
      setAssignments(assignmentsData);
      setSystemLogs(logsData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  // User Management Functions
  const handleAddUser = async () => {
    if (!newUser.name || !newUser.email) {
      alert('Please fill all required fields');
      return;
    }

    try {
      // In production, create Firebase Auth user first
      // For now, just add to Firestore
      const userId = `user_${Date.now()}`;
      await firestoreService.updateUser(userId, newUser);
      
      await firestoreService.addSystemLog({
        action: 'User Created',
        user: userData.name,
        details: `Created user: ${newUser.name} (${newUser.role})`
      });

      setNewUser({ name: '', email: '', role: 'student', class: '' });
      setShowAddUser(false);
      loadData();
    } catch (error) {
      console.error('Error adding user:', error);
      alert('Failed to add user');
    }
  };

  const handleDeleteUser = async (userId) => {
    if (!window.confirm('Are you sure you want to delete this user?')) return;

    try {
      await firestoreService.deleteUser(userId);
      await firestoreService.addSystemLog({
        action: 'User Deleted',
        user: userData.name,
        details: `Deleted user: ${userId}`
      });
      loadData();
    } catch (error) {
      console.error('Error deleting user:', error);
      alert('Failed to delete user');
    }
  };

  // Timetable Management Functions
  const handleAddTimetable = async () => {
    if (!newTimetable.class || !newTimetable.subject || !newTimetable.teacher) {
      alert('Please fill all required fields');
      return;
    }

    try {
      await firestoreService.addTimetableEntry(newTimetable);
      await firestoreService.addSystemLog({
        action: 'Timetable Updated',
        user: userData.name,
        details: `Added ${newTimetable.subject} for ${newTimetable.class}`
      });

      setNewTimetable({
        class: '',
        day: 'Monday',
        period: '1',
        subject: '',
        teacher: '',
        time: ''
      });
      setShowAddTimetable(false);
      loadData();
    } catch (error) {
      console.error('Error adding timetable:', error);
      alert('Failed to add timetable entry');
    }
  };

  const handleDeleteTimetable = async (timetableId) => {
    if (!window.confirm('Are you sure you want to delete this timetable entry?')) return;

    try {
      await firestoreService.deleteTimetableEntry(timetableId);
      await firestoreService.addSystemLog({
        action: 'Timetable Updated',
        user: userData.name,
        details: `Deleted timetable entry`
      });
      loadData();
    } catch (error) {
      console.error('Error deleting timetable:', error);
      alert('Failed to delete timetable entry');
    }
  };

  const handleLogout = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  // Filter users based on search
  const filteredUsers = users.filter(user =>
    user.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.role?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const stats = {
    totalUsers: users.length,
    students: users.filter(u => u.role === 'student').length,
    teachers: users.filter(u => u.role === 'teacher').length,
    assignments: assignments.length
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Bar */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-blue-600">Admin Dashboard</h1>
              <p className="text-sm text-gray-600">Welcome back, {userData?.name}</p>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition"
            >
              <LogOut size={16} />
              Logout
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Users</p>
                <p className="text-2xl font-bold text-gray-800">{stats.totalUsers}</p>
              </div>
              <Users className="text-blue-600" size={32} />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Students</p>
                <p className="text-2xl font-bold text-gray-800">{stats.students}</p>
              </div>
              <BookOpen className="text-green-600" size={32} />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Teachers</p>
                <p className="text-2xl font-bold text-gray-800">{stats.teachers}</p>
              </div>
              <Users className="text-purple-600" size={32} />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Assignments</p>
                <p className="text-2xl font-bold text-gray-800">{stats.assignments}</p>
              </div>
              <FileText className="text-orange-600" size={32} />
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto">
          <button
            onClick={() => setActiveTab('users')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium whitespace-nowrap ${
              activeTab === 'users' 
                ? 'bg-blue-600 text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            <Users size={20} />
            Users
          </button>
          <button
            onClick={() => setActiveTab('timetables')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium whitespace-nowrap ${
              activeTab === 'timetables' 
                ? 'bg-blue-600 text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            <Calendar size={20} />
            Timetables
          </button>
          <button
            onClick={() => setActiveTab('logs')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium whitespace-nowrap ${
              activeTab === 'logs' 
                ? 'bg-blue-600 text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            <FileText size={20} />
            System Logs
          </button>
        </div>

        {/* Users Tab */}
        {activeTab === 'users' && (
          <div className="bg-white rounded-lg shadow">
            <div className="p-6 border-b">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <h2 className="text-xl font-bold">User Management</h2>
                <div className="flex gap-2 w-full md:w-auto">
                  <div className="relative flex-1 md:flex-initial">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                    <input
                      type="text"
                      placeholder="Search users..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 pr-4 py-2 border rounded-lg w-full md:w-64"
                    />
                  </div>
                  <button
                    onClick={() => setShowAddUser(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 whitespace-nowrap"
                  >
                    <Plus size={16} />
                    Add User
                  </button>
                </div>
              </div>
            </div>

            {/* Add User Form */}
            {showAddUser && (
              <div className="p-6 bg-gray-50 border-b">
                <h3 className="font-semibold mb-4">Add New User</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input
                    type="text"
                    placeholder="Full Name *"
                    value={newUser.name}
                    onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                    className="px-4 py-2 border rounded-lg"
                  />
                  <input
                    type="email"
                    placeholder="Email *"
                    value={newUser.email}
                    onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                    className="px-4 py-2 border rounded-lg"
                  />
                  <select
                    value={newUser.role}
                    onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}
                    className="px-4 py-2 border rounded-lg"
                  >
                    <option value="student">Student</option>
                    <option value="teacher">Teacher</option>
                    <option value="admin">Admin</option>
                  </select>
                  <input
                    type="text"
                    placeholder="Class (e.g., 10A)"
                    value={newUser.class}
                    onChange={(e) => setNewUser({ ...newUser, class: e.target.value })}
                    className="px-4 py-2 border rounded-lg"
                  />
                </div>
                <div className="flex gap-2 mt-4">
                  <button
                    onClick={handleAddUser}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Save User
                  </button>
                  <button
                    onClick={() => setShowAddUser(false)}
                    className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            {/* Users Table */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Role</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Class</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredUsers.map(user => (
                    <tr key={user.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="font-medium text-gray-900">{user.name}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                        {user.email}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          user.role === 'admin' ? 'bg-purple-100 text-purple-700' :
                          user.role === 'teacher' ? 'bg-blue-100 text-blue-700' :
                          'bg-green-100 text-green-700'
                        }`}>
                          {user.role}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                        {user.class || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <button
                          onClick={() => handleDeleteUser(user.id)}
                          className="text-red-600 hover:text-red-800"
                        >
                          <Trash2 size={16} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Timetables Tab */}
        {activeTab === 'timetables' && (
          <div className="bg-white rounded-lg shadow">
            <div className="p-6 border-b">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold">Timetable Management</h2>
                <button
                  onClick={() => setShowAddTimetable(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  <Plus size={16} />
                  Add Entry
                </button>
              </div>
            </div>

            {/* Add Timetable Form */}
            {showAddTimetable && (
              <div className="p-6 bg-gray-50 border-b">
                <h3 className="font-semibold mb-4">Add Timetable Entry</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <input
                    type="text"
                    placeholder="Class (e.g., 10A)"
                    value={newTimetable.class}
                    onChange={(e) => setNewTimetable({ ...newTimetable, class: e.target.value })}
                    className="px-4 py-2 border rounded-lg"
                  />
                  <select
                    value={newTimetable.day}
                    onChange={(e) => setNewTimetable({ ...newTimetable, day: e.target.value })}
                    className="px-4 py-2 border rounded-lg"
                  >
                    <option>Monday</option>
                    <option>Tuesday</option>
                    <option>Wednesday</option>
                    <option>Thursday</option>
                    <option>Friday</option>
                  </select>
                  <input
                    type="text"
                    placeholder="Period"
                    value={newTimetable.period}
                    onChange={(e) => setNewTimetable({ ...newTimetable, period: e.target.value })}
                    className="px-4 py-2 border rounded-lg"
                  />
                  <input
                    type="text"
                    placeholder="Subject"
                    value={newTimetable.subject}
                    onChange={(e) => setNewTimetable({ ...newTimetable, subject: e.target.value })}
                    className="px-4 py-2 border rounded-lg"
                  />
                  <input
                    type="text"
                    placeholder="Teacher Name"
                    value={newTimetable.teacher}
                    onChange={(e) => setNewTimetable({ ...newTimetable, teacher: e.target.value })}
                    className="px-4 py-2 border rounded-lg"
                  />
                  <input
                    type="text"
                    placeholder="Time (e.g., 9:00-10:00)"
                    value={newTimetable.time}
                    onChange={(e) => setNewTimetable({ ...newTimetable, time: e.target.value })}
                    className="px-4 py-2 border rounded-lg"
                  />
                </div>
                <div className="flex gap-2 mt-4">
                  <button
                    onClick={handleAddTimetable}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Add Entry
                  </button>
                  <button
                    onClick={() => setShowAddTimetable(false)}
                    className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            {/* Timetable Table */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Class</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Day</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Period</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Subject</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Teacher</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {timetables.map(entry => (
                    <tr key={entry.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap font-medium">{entry.class}</td>
                      <td className="px-6 py-4 whitespace-nowrap">{entry.day}</td>
                      <td className="px-6 py-4 whitespace-nowrap">{entry.period}</td>
                      <td className="px-6 py-4 whitespace-nowrap">{entry.time}</td>
                      <td className="px-6 py-4 whitespace-nowrap font-medium">{entry.subject}</td>
                      <td className="px-6 py-4 whitespace-nowrap">{entry.teacher}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <button
                          onClick={() => handleDeleteTimetable(entry.id)}
                          className="text-red-600 hover:text-red-800"
                        >
                          <Trash2 size={16} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* System Logs Tab */}
        {activeTab === 'logs' && (
          <div className="bg-white rounded-lg shadow">
            <div className="p-6 border-b">
              <h2 className="text-xl font-bold">System Activity Logs</h2>
            </div>
            <div className="p-6">
              <div className="space-y-3">
                {systemLogs.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No logs available</p>
                ) : (
                  systemLogs.map((log, index) => (
                    <div key={index} className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                      <div className={`p-2 rounded-full ${
                        log.action?.includes('Created') ? 'bg-green-100' :
                        log.action?.includes('Deleted') ? 'bg-red-100' :
                        'bg-blue-100'
                      }`}>
                        {log.action?.includes('Created') ? (
                          <CheckCircle className="text-green-600" size={16} />
                        ) : log.action?.includes('Deleted') ? (
                          <AlertCircle className="text-red-600" size={16} />
                        ) : (
                          <Clock className="text-blue-600" size={16} />
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">{log.action}</p>
                        <p className="text-sm text-gray-600">{log.details}</p>
                        <p className="text-xs text-gray-500 mt-1">
                          By {log.user} • {log.timestamp?.toDate?.()?.toLocaleString() || 'Recently'}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;