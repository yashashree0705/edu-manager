// src/components/teacher/TeacherDashboard.jsx
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import firestoreService from '../../services/firestoreService';
import storageService from '../../services/storageService';
import { 
  Calendar, FileText, LogOut, Upload, Trash2, 
  Clock, BookOpen, Users, Download, Edit2, Plus 
} from 'lucide-react';

const TeacherDashboard = () => {
  const { userData, signOut } = useAuth();
  const [activeTab, setActiveTab] = useState('assignments');
  const [assignments, setAssignments] = useState([]);
  const [timetables, setTimetables] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Assignment Upload State
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploading, setUploading] = useState(false);
  const [newAssignment, setNewAssignment] = useState({
    title: '',
    subject: '',
    description: '',
    dueDate: '',
    class: ''
  });
  const [selectedFile, setSelectedFile] = useState(null);

  // Timetable Edit State
  const [editingTimetable, setEditingTimetable] = useState(null);

  useEffect(() => {
    loadData();
    
    // Set up real-time listener for assignments
    const unsubscribe = firestoreService.onAssignmentsSnapshot(
      userData?.class || 'all',
      (data) => setAssignments(data)
    );

    return () => unsubscribe && unsubscribe();
  }, [userData]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [assignmentsData, timetablesData] = await Promise.all([
        firestoreService.getAssignments(),
        firestoreService.getTimetables(userData?.class)
      ]);
      
      setAssignments(assignmentsData);
      setTimetables(timetablesData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      try {
        storageService.validateFile(file, 10, [
          'application/pdf',
          'application/msword',
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          'image/jpeg',
          'image/png'
        ]);
        setSelectedFile(file);
      } catch (error) {
        alert(error.message);
        e.target.value = '';
      }
    }
  };

  const handleUploadAssignment = async () => {
    if (!newAssignment.title || !newAssignment.subject || !newAssignment.dueDate || !newAssignment.class) {
      alert('Please fill all required fields');
      return;
    }

    setUploading(true);
    setUploadProgress(0);

    try {
      let fileUrl = '';
      let fileName = '';

      // Upload file if selected
      if (selectedFile) {
        const uploadResult = await storageService.uploadAssignment(
          selectedFile,
          `assignment_${Date.now()}`,
          (progress) => setUploadProgress(progress)
        );
        fileUrl = uploadResult.url;
        fileName = uploadResult.name;
      }

      // Create assignment document
      await firestoreService.addAssignment({
        ...newAssignment,
        uploadedBy: userData.uid,
        uploadedByName: userData.name,
        fileUrl,
        fileName
      });

      // Log activity
      await firestoreService.addSystemLog({
        action: 'Assignment Uploaded',
        user: userData.name,
        details: `${newAssignment.title} for ${newAssignment.class}`
      });

      // Reset form
      setNewAssignment({
        title: '',
        subject: '',
        description: '',
        dueDate: '',
        class: ''
      });
      setSelectedFile(null);
      setShowUploadForm(false);
      setUploadProgress(0);
      
      alert('Assignment uploaded successfully!');
    } catch (error) {
      console.error('Error uploading assignment:', error);
      alert('Failed to upload assignment');
    } finally {
      setUploading(false);
    }
  };

  const handleDeleteAssignment = async (assignmentId, fileUrl) => {
    if (!window.confirm('Are you sure you want to delete this assignment?')) return;

    try {
      await firestoreService.deleteAssignment(assignmentId);
      
      // Delete associated file if exists
      if (fileUrl) {
        // Extract path from URL and delete
        await storageService.deleteAssignmentFiles(assignmentId);
      }

      await firestoreService.addSystemLog({
        action: 'Assignment Deleted',
        user: userData.name,
        details: `Deleted assignment: ${assignmentId}`
      });

      loadData();
    } catch (error) {
      console.error('Error deleting assignment:', error);
      alert('Failed to delete assignment');
    }
  };

  const handleUpdateTimetable = async (timetableId, updates) => {
    try {
      await firestoreService.updateTimetableEntry(timetableId, updates);
      
      await firestoreService.addSystemLog({
        action: 'Timetable Updated',
        user: userData.name,
        details: `Updated timetable entry`
      });

      setEditingTimetable(null);
      loadData();
    } catch (error) {
      console.error('Error updating timetable:', error);
      alert('Failed to update timetable');
    }
  };

  const handleLogout = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const myAssignments = assignments.filter(a => a.uploadedBy === userData?.uid);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Bar */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-green-600">Teacher Dashboard</h1>
              <p className="text-sm text-gray-600">Welcome back, {userData?.name}</p>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition"
            >
              <LogOut size={16} />
              Logout
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">My Assignments</p>
                <p className="text-2xl font-bold text-gray-800">{myAssignments.length}</p>
              </div>
              <FileText className="text-green-600" size={32} />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Classes</p>
                <p className="text-2xl font-bold text-gray-800">{timetables.length}</p>
              </div>
              <Calendar className="text-blue-600" size={32} />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Submissions</p>
                <p className="text-2xl font-bold text-gray-800">{submissions.length}</p>
              </div>
              <Users className="text-purple-600" size={32} />
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto">
          <button
            onClick={() => setActiveTab('assignments')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium whitespace-nowrap ${
              activeTab === 'assignments' 
                ? 'bg-green-600 text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            <FileText size={20} />
            Assignments
          </button>
          <button
            onClick={() => setActiveTab('timetable')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium whitespace-nowrap ${
              activeTab === 'timetable' 
                ? 'bg-green-600 text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            <Calendar size={20} />
            Timetable
          </button>
        </div>

        {/* Assignments Tab */}
        {activeTab === 'assignments' && (
          <div className="bg-white rounded-lg shadow">
            <div className="p-6 border-b">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold">My Assignments</h2>
                <button
                  onClick={() => setShowUploadForm(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  <Upload size={16} />
                  Upload Assignment
                </button>
              </div>
            </div>

            {/* Upload Form */}
            {showUploadForm && (
              <div className="p-6 bg-gray-50 border-b">
                <h3 className="font-semibold mb-4">Upload New Assignment</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input
                      type="text"
                      placeholder="Assignment Title *"
                      value={newAssignment.title}
                      onChange={(e) => setNewAssignment({ ...newAssignment, title: e.target.value })}
                      className="px-4 py-2 border rounded-lg"
                    />
                    <input
                      type="text"
                      placeholder="Subject *"
                      value={newAssignment.subject}
                      onChange={(e) => setNewAssignment({ ...newAssignment, subject: e.target.value })}
                      className="px-4 py-2 border rounded-lg"
                    />
                    <input
                      type="date"
                      value={newAssignment.dueDate}
                      onChange={(e) => setNewAssignment({ ...newAssignment, dueDate: e.target.value })}
                      className="px-4 py-2 border rounded-lg"
                    />
                    <input
                      type="text"
                      placeholder="Class (e.g., 10A) *"
                      value={newAssignment.class}
                      onChange={(e) => setNewAssignment({ ...newAssignment, class: e.target.value })}
                      className="px-4 py-2 border rounded-lg"
                    />
                  </div>
                  
                  <textarea
                    placeholder="Description"
                    value={newAssignment.description}
                    onChange={(e) => setNewAssignment({ ...newAssignment, description: e.target.value })}
                    className="w-full px-4 py-2 border rounded-lg"
                    rows="3"
                  />

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Attach File (Optional)
                    </label>
                    <input
                      type="file"
                      onChange={handleFileSelect}
                      accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                      className="w-full px-4 py-2 border rounded-lg"
                    />
                    {selectedFile && (
                      <p className="mt-2 text-sm text-gray-600">
                        Selected: {selectedFile.name} ({storageService.formatFileSize(selectedFile.size)})
                      </p>
                    )}
                  </div>

                  {uploading && (
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-green-600 h-2 rounded-full transition-all"
                        style={{ width: `${uploadProgress}%` }}
                      />
                    </div>
                  )}
                </div>

                <div className="flex gap-2 mt-4">
                  <button
                    onClick={handleUploadAssignment}
                    disabled={uploading}
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
                  >
                    {uploading ? `Uploading... ${Math.round(uploadProgress)}%` : 'Upload Assignment'}
                  </button>
                  <button
                    onClick={() => {
                      setShowUploadForm(false);
                      setSelectedFile(null);
                      setUploadProgress(0);
                    }}
                    disabled={uploading}
                    className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            {/* Assignments List */}
            <div className="p-6">
              {myAssignments.length === 0 ? (
                <div className="text-center py-12">
                  <FileText className="mx-auto text-gray-400 mb-4" size={48} />
                  <p className="text-gray-500">No assignments uploaded yet</p>
                  <button
                    onClick={() => setShowUploadForm(true)}
                    className="mt-4 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                  >
                    Upload Your First Assignment
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {myAssignments.map(assignment => (
                    <div key={assignment.id} className="p-4 border rounded-lg hover:shadow-md transition">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg">{assignment.title}</h3>
                          <div className="flex flex-wrap gap-2 mt-2">
                            <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-sm">
                              {assignment.subject}
                            </span>
                            <span className="px-2 py-1 bg-green-100 text-green-700 rounded text-sm">
                              Class {assignment.class}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600 mt-2">{assignment.description}</p>
                          {assignment.fileName && (
                            <p className="text-xs text-gray-500 mt-1">
                              📎 {assignment.fileName}
                            </p>
                          )}
                        </div>
                        <div className="flex flex-col items-end gap-2 ml-4">
                          <span className="text-sm text-gray-500 whitespace-nowrap">
                            Due: {assignment.dueDate}
                          </span>
                          <button
                            onClick={() => handleDeleteAssignment(assignment.id, assignment.fileUrl)}
                            className="text-red-600 hover:text-red-800"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Timetable Tab */}
        {activeTab === 'timetable' && (
          <div className="bg-white rounded-lg shadow">
            <div className="p-6 border-b">
              <h2 className="text-xl font-bold">My Timetable</h2>
              <p className="text-sm text-gray-600 mt-1">View and manage your class schedule</p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Day</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Period</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Subject</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Class</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {timetables.length === 0 ? (
                    <tr>
                      <td colSpan="5" className="px-6 py-12 text-center text-gray-500">
                        No timetable entries found
                      </td>
                    </tr>
                  ) : (
                    timetables.map(entry => (
                      <tr key={entry.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap font-medium">{entry.day}</td>
                        <td className="px-6 py-4 whitespace-nowrap">{entry.period}</td>
                        <td className="px-6 py-4 whitespace-nowrap">{entry.time}</td>
                        <td className="px-6 py-4 whitespace-nowrap font-medium text-green-600">
                          {entry.subject}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">{entry.class}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TeacherDashboard;