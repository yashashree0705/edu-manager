// src/services/storageService.js
import { 
  ref, 
  uploadBytes, 
  uploadBytesResumable,
  getDownloadURL, 
  deleteObject,
  listAll
} from 'firebase/storage';
import { storage } from '../config/firebase';

class StorageService {
  // Upload file with progress tracking
  uploadFile(file, path, onProgress = null) {
    return new Promise((resolve, reject) => {
      const storageRef = ref(storage, path);
      const uploadTask = uploadBytesResumable(storageRef, file);

      uploadTask.on(
        'state_changed',
        (snapshot) => {
          // Calculate progress percentage
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          if (onProgress) {
            onProgress(progress);
          }
        },
        (error) => {
          // Handle errors
          console.error('Upload error:', error);
          reject(error);
        },
        async () => {
          // Get download URL on successful upload
          try {
            const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
            resolve({
              url: downloadURL,
              path: path,
              name: file.name,
              size: file.size,
              type: file.type
            });
          } catch (error) {
            reject(error);
          }
        }
      );
    });
  }

  // Upload assignment file
  async uploadAssignment(file, assignmentId, onProgress = null) {
    try {
      const timestamp = Date.now();
      const fileName = `${timestamp}_${file.name}`;
      const path = `assignments/${assignmentId}/${fileName}`;
      
      return await this.uploadFile(file, path, onProgress);
    } catch (error) {
      console.error('Error uploading assignment:', error);
      throw error;
    }
  }

  // Upload submission file
  async uploadSubmission(file, assignmentId, studentId, onProgress = null) {
    try {
      const timestamp = Date.now();
      const fileName = `${timestamp}_${file.name}`;
      const path = `submissions/${assignmentId}/${studentId}/${fileName}`;
      
      return await this.uploadFile(file, path, onProgress);
    } catch (error) {
      console.error('Error uploading submission:', error);
      throw error;
    }
  }

  // Get download URL for a file
  async getDownloadURL(path) {
    try {
      const storageRef = ref(storage, path);
      return await getDownloadURL(storageRef);
    } catch (error) {
      console.error('Error getting download URL:', error);
      throw error;
    }
  }

  // Delete file
  async deleteFile(path) {
    try {
      const storageRef = ref(storage, path);
      await deleteObject(storageRef);
    } catch (error) {
      console.error('Error deleting file:', error);
      throw error;
    }
  }

  // List all files in a directory
  async listFiles(path) {
    try {
      const storageRef = ref(storage, path);
      const result = await listAll(storageRef);
      
      const files = await Promise.all(
        result.items.map(async (itemRef) => {
          const url = await getDownloadURL(itemRef);
          return {
            name: itemRef.name,
            path: itemRef.fullPath,
            url: url
          };
        })
      );
      
      return files;
    } catch (error) {
      console.error('Error listing files:', error);
      throw error;
    }
  }

  // Delete all files in assignment folder
  async deleteAssignmentFiles(assignmentId) {
    try {
      const path = `assignments/${assignmentId}`;
      const storageRef = ref(storage, path);
      const result = await listAll(storageRef);
      
      // Delete all files
      await Promise.all(
        result.items.map(itemRef => deleteObject(itemRef))
      );
    } catch (error) {
      console.error('Error deleting assignment files:', error);
      throw error;
    }
  }

  // Validate file before upload
  validateFile(file, maxSizeMB = 10, allowedTypes = []) {
    const maxSize = maxSizeMB * 1024 * 1024; // Convert MB to bytes
    
    // Check file size
    if (file.size > maxSize) {
      throw new Error(`File size exceeds ${maxSizeMB}MB limit`);
    }
    
    // Check file type if specified
    if (allowedTypes.length > 0 && !allowedTypes.includes(file.type)) {
      throw new Error(`File type ${file.type} is not allowed`);
    }
    
    return true;
  }

  // Get file extension
  getFileExtension(filename) {
    return filename.slice((filename.lastIndexOf(".") - 1 >>> 0) + 2);
  }

  // Format file size
  formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  }
}

export default new StorageService();