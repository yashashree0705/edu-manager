// src/services/firestoreService.js
import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy,
  serverTimestamp,
  onSnapshot
} from 'firebase/firestore';
import { db } from '../config/firebase';

class FirestoreService {
  // ========== USERS ==========
  async getUsers() {
    try {
      const querySnapshot = await getDocs(collection(db, 'users'));
      return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
      console.error('Error getting users:', error);
      throw error;
    }
  }

  async getUserById(userId) {
    try {
      const docSnap = await getDoc(doc(db, 'users', userId));
      return docSnap.exists() ? { id: docSnap.id, ...docSnap.data() } : null;
    } catch (error) {
      console.error('Error getting user:', error);
      throw error;
    }
  }

  async updateUser(userId, userData) {
    try {
      await updateDoc(doc(db, 'users', userId), {
        ...userData,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Error updating user:', error);
      throw error;
    }
  }

  async deleteUser(userId) {
    try {
      await deleteDoc(doc(db, 'users', userId));
    } catch (error) {
      console.error('Error deleting user:', error);
      throw error;
    }
  }

  // ========== TIMETABLES ==========
  async getTimetables(classId = null) {
    try {
      let q = collection(db, 'timetables');
      
      if (classId) {
        q = query(q, where('class', '==', classId), orderBy('day'), orderBy('period'));
      }
      
      const querySnapshot = await getDocs(q);
      return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
      console.error('Error getting timetables:', error);
      throw error;
    }
  }

  async addTimetableEntry(timetableData) {
    try {
      const docRef = await addDoc(collection(db, 'timetables'), {
        ...timetableData,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      return docRef.id;
    } catch (error) {
      console.error('Error adding timetable entry:', error);
      throw error;
    }
  }

  async updateTimetableEntry(timetableId, timetableData) {
    try {
      await updateDoc(doc(db, 'timetables', timetableId), {
        ...timetableData,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Error updating timetable entry:', error);
      throw error;
    }
  }

  async deleteTimetableEntry(timetableId) {
    try {
      await deleteDoc(doc(db, 'timetables', timetableId));
    } catch (error) {
      console.error('Error deleting timetable entry:', error);
      throw error;
    }
  }

  // Real-time listener for timetables
  onTimetableSnapshot(classId, callback) {
    const q = query(
      collection(db, 'timetables'), 
      where('class', '==', classId),
      orderBy('day'),
      orderBy('period')
    );
    
    return onSnapshot(q, (snapshot) => {
      const timetables = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      callback(timetables);
    });
  }

  // ========== ASSIGNMENTS ==========
  async getAssignments(classId = null) {
    try {
      let q = collection(db, 'assignments');
      
      if (classId) {
        q = query(q, where('class', '==', classId), orderBy('dueDate', 'desc'));
      } else {
        q = query(q, orderBy('createdAt', 'desc'));
      }
      
      const querySnapshot = await getDocs(q);
      return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
      console.error('Error getting assignments:', error);
      throw error;
    }
  }

  async addAssignment(assignmentData) {
    try {
      const docRef = await addDoc(collection(db, 'assignments'), {
        ...assignmentData,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      return docRef.id;
    } catch (error) {
      console.error('Error adding assignment:', error);
      throw error;
    }
  }

  async updateAssignment(assignmentId, assignmentData) {
    try {
      await updateDoc(doc(db, 'assignments', assignmentId), {
        ...assignmentData,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Error updating assignment:', error);
      throw error;
    }
  }

  async deleteAssignment(assignmentId) {
    try {
      await deleteDoc(doc(db, 'assignments', assignmentId));
    } catch (error) {
      console.error('Error deleting assignment:', error);
      throw error;
    }
  }

  // Real-time listener for assignments
  onAssignmentsSnapshot(classId, callback) {
    const q = query(
      collection(db, 'assignments'), 
      where('class', '==', classId),
      orderBy('dueDate', 'desc')
    );
    
    return onSnapshot(q, (snapshot) => {
      const assignments = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      callback(assignments);
    });
  }

  // ========== SUBMISSIONS ==========
  async getSubmissions(assignmentId = null, studentId = null) {
    try {
      let q = collection(db, 'submissions');
      
      if (assignmentId) {
        q = query(q, where('assignmentId', '==', assignmentId));
      }
      
      if (studentId) {
        q = query(q, where('studentId', '==', studentId));
      }
      
      const querySnapshot = await getDocs(q);
      return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
      console.error('Error getting submissions:', error);
      throw error;
    }
  }

  async addSubmission(submissionData) {
    try {
      const docRef = await addDoc(collection(db, 'submissions'), {
        ...submissionData,
        submittedAt: serverTimestamp()
      });
      return docRef.id;
    } catch (error) {
      console.error('Error adding submission:', error);
      throw error;
    }
  }

  async updateSubmission(submissionId, submissionData) {
    try {
      await updateDoc(doc(db, 'submissions', submissionId), {
        ...submissionData,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Error updating submission:', error);
      throw error;
    }
  }

  // ========== SYSTEM LOGS ==========
  async addSystemLog(logData) {
    try {
      await addDoc(collection(db, 'system_logs'), {
        ...logData,
        timestamp: serverTimestamp()
      });
    } catch (error) {
      console.error('Error adding system log:', error);
      throw error;
    }
  }

  async getSystemLogs(limit = 50) {
    try {
      const q = query(
        collection(db, 'system_logs'), 
        orderBy('timestamp', 'desc')
      );
      
      const querySnapshot = await getDocs(q);
      return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
      console.error('Error getting system logs:', error);
      throw error;
    }
  }
}

export default new FirestoreService();